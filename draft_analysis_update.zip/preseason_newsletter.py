"""LeagueLab preseason newsletter.

Usage:
    python -m leaguelab.preseason_newsletter --season 2026

The builder reads:
    data/config/<season>/preseason.json
    data/config/<season>/dues.json

preseason.json is intentionally data-driven.  Draft analytics can populate the
same schema after Yahoo draft/projection inspection without changing the HTML.
Python 3.8 compatible.
"""
import argparse
import json
from html import escape
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
CONFIG_ROOT = PROJECT_ROOT / "data" / "config"
OUTPUT_ROOT = PROJECT_ROOT / "output"

CHALLENGES = [
    ("Hot Start", "Weeks 1-2", 10, "Most total starting-lineup points across the two challenge weeks."),
    ("Dynamic Duo", "Weeks 3-4", 10, "Most combined points from each team's two highest-scoring starters each week."),
    ("Flex Appeal", "Weeks 5-6", 10, "Most points scored from the W/R/T flex positions across the two weeks."),
    ("Depth Charge", "Weeks 7-8", 10, "Most combined points from RB2, WR2, FLEX1 and FLEX2 across the two weeks."),
    ("Perfect Lineup", "Weeks 9-10", 10, "Highest lineup efficiency: actual starter points divided by the optimal legal lineup."),
    ("No Weak Links", "Weeks 11-12", 10, "Highest combined score from each team's lowest-scoring starter each week."),
    ("Finish Strong", "Weeks 13-14", 10, "Largest improvement over the team's expected two-week score based on its Weeks 1-12 average."),
    ("Season Points", "Weeks 1-14", 20, "Most total fantasy points scored during the 14-week regular season."),
]

DEFAULT_PAYOUTS = [
    ("1st Place", 210),
    ("2nd Place", 100),
    ("3rd Place", 40),
    ("Toilet Bowl", 40),
    ("Challenges", 90),
]


def _load_json(path, default=None):
    if not path.exists():
        return {} if default is None else default
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _money(value):
    return "${:,.0f}".format(float(value or 0))


def _section(title, body, subtitle=""):
    sub = '<div class="section-sub">{}</div>'.format(escape(subtitle)) if subtitle else ""
    return '<div class="section"><h2>{}</h2>{}{}</div>'.format(escape(title), sub, body)


def _table(headers, rows):
    head = "".join("<th>{}</th>".format(escape(str(h))) for h in headers)
    body = []
    for row in rows:
        body.append("<tr>{}</tr>".format("".join(
            "<td>{}</td>".format(value) for value in row
        )))
    return '<div class="table-wrap"><table><thead><tr>{}</tr></thead><tbody>{}</tbody></table></div>'.format(
        head, "".join(body)
    )


def _welcome(data, season):
    message = data.get("welcome_message") or (
        "Welcome back to XTreme Football. The draft is complete and another "
        "season is ready to go. Here is your preseason look at the league."
    )
    return _section(
        "🏈 Welcome to the {} Season".format(season),
        '<div class="welcome-copy">{}</div>'.format(escape(message)),
    )


def _payouts(data):
    configured = data.get("payouts") or {}
    rows = []
    total = 0
    for label, default in DEFAULT_PAYOUTS:
        key = label.lower().replace(" ", "_")
        amount = configured.get(key, default)
        total += float(amount)
        rows.append([escape(label), '<strong>{}</strong>'.format(_money(amount))])
    rows.append(['<strong>Total</strong>', '<strong>{}</strong>'.format(_money(total))])
    return _section("💰 Payout Structure", _table(["Award", "Payout"], rows))


def _challenges(data):
    overrides = data.get("challenges") or {}
    rows = []
    for name, weeks, prize, description in CHALLENGES:
        item = overrides.get(name, {}) if isinstance(overrides, dict) else {}
        rows.append([
            '<strong>{}</strong>'.format(escape(name)),
            escape(str(item.get("weeks", weeks))),
            '<strong>{}</strong>'.format(_money(item.get("prize", prize))),
            escape(str(item.get("description", description))),
        ])
    return _section(
        "🏆 Challenge Schedule",
        _table(["Challenge", "Weeks", "Payout", "Description"], rows),
        "$90 total challenge pool",
    )


def _dues(season):
    cfg = _load_json(CONFIG_ROOT / str(season) / "dues.json", {})
    amount = cfg.get("amount_per_team", 40)
    teams = cfg.get("teams") or {}
    rows = []
    for key, item in teams.items():
        if not isinstance(item, dict):
            continue
        name = item.get("team_name") or item.get("name") or key
        paid = bool(item.get("paid"))
        rows.append([
            escape(str(name)),
            _money(amount),
            '<span class="paid">Paid</span>' if paid else '<span class="unpaid">Due</span>',
        ])
    if not rows:
        return _section(
            "💵 League Dues",
            '<div class="empty">Dues status will appear here once dues.json is populated.</div>',
            "{} per team".format(_money(amount)),
        )
    return _section("💵 League Dues", _table(["Team", "Dues", "Status"], rows), "{} per team".format(_money(amount)))


def _draft_report(data):
    teams = data.get("draft_report") or []
    if not teams:
        return _section(
            "📋 Draft Report",
            '<div class="empty">Draft analysis pending Yahoo draft-result and projection analysis.</div>',
        )
    cards = []
    for team in teams:
        tags = []
        for label, key in (("Best Pick", "best_pick"), ("Best Value", "best_value"),
                           ("Biggest Reach", "biggest_reach"), ("Strength", "strength"),
                           ("Weakness", "weakness")):
            value = team.get(key)
            if value:
                tags.append('<div class="draft-fact"><span>{}</span>{}</div>'.format(
                    escape(label), escape(str(value))
                ))
        cards.append(
            '<div class="draft-card"><div class="draft-head"><strong>{}</strong>'
            '<span class="grade">{}</span></div><div class="draft-facts">{}</div>'
            '<p>{}</p></div>'.format(
                escape(str(team.get("team_name", "-"))),
                escape(str(team.get("grade", "-"))),
                "".join(tags),
                escape(str(team.get("assessment", ""))),
            )
        )
    return _section("📋 Draft Report", '<div class="draft-grid">{}</div>'.format("".join(cards)))


def _projected_standings(data):
    rows = data.get("projected_standings") or []
    if not rows:
        return _section(
            "📊 Projected Standings",
            '<div class="empty">Projected optimal-lineup standings pending Yahoo projection data.</div>',
            "Based on each roster's optimal legal projected lineup",
        )
    table_rows = []
    for idx, row in enumerate(rows, 1):
        table_rows.append([
            str(row.get("rank", idx)),
            escape(str(row.get("team_name", "-"))),
            "{:.2f}".format(float(row.get("projected_points", 0))),
            escape(str(row.get("strength", ""))),
        ])
    return _section(
        "📊 Projected Standings",
        _table(["Rank", "Team", "Optimal Proj.", "Strength"], table_rows),
        "Based on each roster's optimal legal projected lineup",
    )


def _players_to_watch(data):
    items = data.get("players_to_watch") or []
    if not items:
        return _section("⭐ Players to Watch", '<div class="empty">Players to watch will be selected from the completed draft analysis.</div>')
    cards = []
    for item in items:
        cards.append(
            '<div class="mini-card"><div class="mini-label">{}</div><strong>{}</strong>'
            '<div class="mini-detail">{}</div></div>'.format(
                escape(str(item.get("label", "Player to Watch"))),
                escape(str(item.get("player_name", "-"))),
                escape(str(item.get("detail", ""))),
            )
        )
    return _section("⭐ Players to Watch", '<div class="mini-grid">{}</div>'.format("".join(cards)))


def _power_rankings(data):
    rows = data.get("power_rankings") or []
    if not rows:
        return _section("🔮 Preseason Power Rankings", '<div class="empty">Preseason rankings pending draft and projection analysis.</div>')
    table_rows = []
    for idx, row in enumerate(rows, 1):
        table_rows.append([
            str(row.get("rank", idx)),
            escape(str(row.get("team_name", "-"))),
            escape(str(row.get("rating", ""))),
            escape(str(row.get("note", ""))),
        ])
    return _section("🔮 Preseason Power Rankings", _table(["Rank", "Team", "Rating", "Outlook"], table_rows))


def _week_one(data):
    matchups = data.get("week_1_matchups") or []
    if not matchups:
        return _section("⚔️ Week 1 Matchups", '<div class="empty">Week 1 matchup projections pending Yahoo schedule/projection data.</div>')
    cards = []
    for item in matchups:
        a = item.get("team_a") or {}
        b = item.get("team_b") or {}
        watch = '<div class="watch">MATCHUP TO WATCH</div>' if item.get("matchup_to_watch") else ""
        def team_line(team):
            proj = team.get("projected_points")
            proj_html = ' <span class="projection">• Proj {:.2f}</span>'.format(float(proj)) if proj is not None else ""
            return '<strong>{}</strong>{}'.format(escape(str(team.get("team_name", "-"))), proj_html)
        cards.append('<div class="upcoming">{}<div>{}</div><div class="versus">vs</div><div>{}</div></div>'.format(
            watch, team_line(a), team_line(b)
        ))
    return _section("⚔️ Week 1 Matchups", '<div class="upcoming-grid">{}</div>'.format("".join(cards)))


def build_preseason_html(season):
    data = _load_json(CONFIG_ROOT / str(season) / "preseason.json", {})
    league_name = data.get("league_name", "XTreme Football")

    css = """
    *{box-sizing:border-box}body{margin:0;background:#edf4f8;color:#263746;font-family:Arial,Helvetica,sans-serif}
    .shell{max-width:920px;margin:0 auto;background:#fbfdff}.hero{padding:30px 28px;background:#567b95;color:#fff}
    .hero h1{margin:0;font-size:28px}.hero p{margin:7px 0 0;opacity:.9}.section{padding:22px 28px;border-bottom:1px solid #dce8ef}
    .section h2{margin:0 0 12px;color:#34576e;font-size:19px}.section-sub{margin:-7px 0 12px;color:#718694;font-size:11px}
    .welcome-copy{font-size:14px;line-height:1.55}.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse;font-size:12px}
    th{text-align:left;background:#eaf3f8;padding:9px 8px;border-bottom:2px solid #bfd3df;white-space:nowrap}
    td{padding:9px 8px;border-bottom:1px solid #e1ebf0;vertical-align:top}.paid{font-weight:bold;color:#456b83}.unpaid{font-weight:bold}
    .draft-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.draft-card{padding:14px;background:#f4f9fc;border:1px solid #d3e3ed;border-radius:9px}
    .draft-head{display:flex;justify-content:space-between;align-items:center;font-size:15px}.grade{font-size:24px;color:#567b95}
    .draft-facts{margin-top:8px}.draft-fact{margin-top:5px;font-size:11px}.draft-fact span{display:inline-block;width:84px;color:#718694;text-transform:uppercase;font-size:9px;font-weight:bold}
    .draft-card p{margin:10px 0 0;font-size:12px;line-height:1.45;color:#526b7b}.mini-grid,.upcoming-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
    .mini-card,.upcoming{padding:13px;background:#f0f7fb;border:1px solid #d1e1ea;border-radius:8px}.mini-label,.watch{font-size:9px;text-transform:uppercase;letter-spacing:.6px;color:#6f98b3;font-weight:bold}
    .mini-detail{margin-top:5px;font-size:11px;color:#6c8190}.versus{margin:6px 0;color:#8a9ba6;font-size:10px;text-transform:uppercase}
    .projection{color:#6f98b3;font-size:10px}.empty{padding:14px;background:#f7fbfd;border:1px dashed #c8d8e2;border-radius:8px;color:#7b909e;font-size:12px}
    .footer{padding:20px 28px;text-align:center;color:#8a9ba6;font-size:10px}
    @media(max-width:650px){.hero,.section{padding-left:16px;padding-right:16px}.draft-grid,.mini-grid,.upcoming-grid{grid-template-columns:1fr}table{font-size:11px}}
    """

    parts = [
        "<!doctype html><html><head><meta charset='utf-8'>",
        "<meta name='viewport' content='width=device-width,initial-scale=1'>",
        "<title>{} Preseason Newsletter</title><style>{}</style></head><body>".format(season, css),
        '<div class="shell">',
        '<div class="hero"><h1>{} Preseason Newsletter</h1><p>LeagueLab • {} • Draft complete. Season loading.</p></div>'.format(
            escape(str(league_name)), season
        ),
        _welcome(data, season),
        _payouts(data),
        _challenges(data),
        _dues(season),
        _draft_report(data),
        _projected_standings(data),
        _players_to_watch(data),
        _power_rankings(data),
        _week_one(data),
        '<div class="footer">Generated by LeagueLab</div></div></body></html>',
    ]
    return "".join(parts)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--season", type=int, required=True)
    args = parser.parse_args()
    html = build_preseason_html(args.season)
    out_dir = OUTPUT_ROOT / str(args.season)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / "preseason_newsletter.html"
    path.write_text(html, encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
